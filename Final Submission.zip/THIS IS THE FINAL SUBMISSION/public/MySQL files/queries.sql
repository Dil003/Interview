--Select all organisations
SELECT * FROM Organisations;

--Select all users
SELECT * FROM Users;

--Select all roles
SELECT * FROM Roles;

--Select all users with their roles
SELECT U.FirstName, U.LastName, R.Name AS RoleName
FROM Users U
JOIN UserRoles UR ON U.Id = UR.UserId
JOIN Roles R ON UR.RoleId = R.Id;

--Select all organisation users with their organisations and roles
SELECT U.FirstName, U.LastName, O.Name AS OrganisationName, R.Name AS RoleName
FROM Users U
JOIN OrganisationUsers OU ON U.Id = OU.UserId
JOIN Organisations O ON OU.OrganisationId = O.Id
JOIN Roles R ON OU.RoleId = R.Id;

--Select all branches and their organisations
SELECT B.City, O.Name AS OrganisationName
FROM Branches B
JOIN Organisations O ON B.OrganisationId = O.Id;

--Select all notifications for a specific organisation
SELECT ONT.Name AS NotificationName, NT.Name AS NotificationTypeName
FROM OrganisationNotificationTypes ONT
JOIN NotificationTypes NT ON ONT.NotificationTypeId = NT.Id
WHERE ONT.OrganisationId = 1;

--Select all events for a specific organisation
SELECT E.Name, E.Description, E.TimeOfEvent, E.Location
FROM Events E
WHERE E.OrganisationId = 1;

--Select all RSVPs for a specific event
SELECT U.FirstName, U.LastName, E.Name AS EventName
FROM RSVPs R
JOIN OrganisationUsers OU ON R.OrganisationUserId = OU.Id
JOIN Users U ON OU.UserId = U.Id
JOIN Events E ON R.EventId = E.Id
WHERE E.Id = 1;

--Count the number of members in each organisation
SELECT O.Name AS OrganisationName, COUNT(OU.Id) AS MemberCount
FROM Organisations O
JOIN OrganisationUsers OU ON O.Id = OU.OrganisationId
GROUP BY O.Name;

--Find all announcements for a specific organisation
SELECT A.Title, A.Content, A.TimeCreated
FROM Announcements A
WHERE A.OrganisationId = 1;

--List all organisation membership notification types
SELECT OMNT.Id, U.FirstName, U.LastName, ONT.Name AS NotificationTypeName
FROM OrganisationMembershipNotificationTypes OMNT
JOIN OrganisationUsers OU ON OMNT.OrganisationUserId = OU.Id
JOIN Users U ON OU.UserId = U.Id
JOIN OrganisationNotificationTypes ONT ON OMNT.OrganisationNotificationTypeId = ONT.Id;
