-- insert sample data into Organisations table
INSERT INTO Organisations (Name, Description, Likes, Visits, Favorites, Conversions, Views, Members, Established) 
VALUES ('Plant trees', 'A team for planting trees around Australia!', 152, 1230, 65, 10, 2200, 200, '2024-04-11'),
       ('Run for Charity ', 'A community promoting health and wellness by running', 200, 1800, 110, 60, 3300, 400, '2023-02-12');

-- insert sample data into Users table
INSERT INTO Users (AuthenticationType, FirstName, LastName, Email, Username, AccountSetup, PhoneNumber, City, DateOfBirth, Twitter, Facebook, Instagram)
VALUES (TRUE, 'dil', 'singh', 'dil.singh@gmail.com', 'dil001', TRUE, '1234567890', 'sydney', '2002-01-27', '@dil001', 'dil001_fb', 'dil001_ig'),
       (FALSE, 'anton', 'b', 'anton.b@gmail.com', 'anton01', FALSE, '2123432321', 'adelaide', '2002-09-12', '@anton01', 'anton01_fb', 'anton01_ig');

-- insert sample data into Roles table
INSERT INTO Roles (Name) VALUES ('Admin'), ('Member'), ('Manager');

-- insert sample data into UserRoles table
INSERT INTO UserRoles (UserId, RoleId) VALUES (1, 1), (2, 2);

-- insert sample data into OrganisationUsers table
INSERT INTO OrganisationUsers (UserId, OrganisationId, RoleId) VALUES (1, 1, 1), (2, 2, 2);

-- insert sample data into Branches table
INSERT INTO Branches (OrganisationId, City) VALUES (1, 'adelaide'), (2, 'sydney');

-- insert sample data into BranchManagers table
INSERT INTO BranchManagers (BranchId, OrganisationUserId) VALUES (1, 1), (2, 2);

-- insert sample data into NotificationTypes table
INSERT INTO NotificationTypes (Name) VALUES ('Email'), ('SMS'), ('Push Notification');

-- insert sample data into OrganisationNotificationTypes table
INSERT INTO OrganisationNotificationTypes (OrganisationId, NotificationTypeId, Name) VALUES (1, 1, 'montly newsletter'), (2, 2, 'Event Reminder');

-- insert sample data into OrganisationMembershipNotificationTypes table
INSERT INTO OrganisationMembershipNotificationTypes (OrganisationUserId, OrganisationNotificationTypeId) VALUES (1, 1), (2, 2);

-- insert sample data into Announcements table
INSERT INTO Announcements (OrganisationId, IsPublic, Title, Content, TimeCreated) 
VALUES (1, TRUE, 'Plant trees', 'Join us for a meetup this Saturday', '2024-08-10 10:00:00'),
       (2, FALSE, 'Run for Charity ' , 'run coming up this weekend', '2024-08-11 09:30:00');

-- insert sample data into Events table
INSERT INTO Events (OrganisationId, Name, Description, TimeOfEvent, Location)
VALUES (1, 'Beach clean up ', 'Beach clean up, clean surroundings and protect nature', '2024-02-15 11:00:00', 'henley beach'),
       (2, 'Yoga', 'morning yoga session', '2024-01-12 08:00:00', 'green park');

-- insert sample data into RSVPs table
INSERT INTO RSVPs (OrganisationUserId, EventId) VALUES (1, 1), (2, 2);