--Drop tables if they already exist
DROP TABLE IF EXISTS RSVPs;
DROP TABLE IF EXISTS Events;
DROP TABLE IF EXISTS Announcements;
DROP TABLE IF EXISTS OrganisationMembershipNotificationTypes;
DROP TABLE IF EXISTS OrganisationNotificationTypes;
DROP TABLE IF EXISTS NotificationTypes;
DROP TABLE IF EXISTS BranchManagers;
DROP TABLE IF EXISTS Branches;
DROP TABLE IF EXISTS OrganisationUsers;
DROP TABLE IF EXISTS Organisations;
DROP TABLE IF EXISTS UserRoles;
DROP TABLE IF EXISTS Roles;
DROP TABLE IF EXISTS Users;

--Organisations table
CREATE TABLE Organisations (
    Id INT PRIMARY KEY AUTO_INCREMENT,
    Name VARCHAR(255),
    Description TEXT,
    Likes INT,
    Visits INT,
    Favorites INT,
    Conversions INT,
    Views INT,
    Members INT,
    Established DATE
);

--Users table
CREATE TABLE Users (
    Id INT PRIMARY KEY AUTO_INCREMENT,
    AuthenticationType BOOLEAN,
    FirstName VARCHAR(255),
    LastName VARCHAR(255),
    Email VARCHAR(255),
    Username VARCHAR(255),
    AccountSetup BOOLEAN,
    PhoneNumber VARCHAR(20),
    City VARCHAR(255),
    DateOfBirth DATE,
    Twitter VARCHAR(255),
    Facebook VARCHAR(255),
    Instagram VARCHAR(255)
);

--Roles table
CREATE TABLE Roles (
    Id INT PRIMARY KEY AUTO_INCREMENT,
    Name VARCHAR(255)
);

--UserRoles table
CREATE TABLE UserRoles (
    Id INT PRIMARY KEY AUTO_INCREMENT,
    UserId INT,
    RoleId INT,
    FOREIGN KEY (UserId) REFERENCES Users(Id),
    FOREIGN KEY (RoleId) REFERENCES Roles(Id)
);

--OrganisationUsers table
CREATE TABLE OrganisationUsers (
    Id INT PRIMARY KEY AUTO_INCREMENT,
    UserId INT,
    OrganisationId INT,
    RoleId INT,
    FOREIGN KEY (UserId) REFERENCES Users(Id),
    FOREIGN KEY (OrganisationId) REFERENCES Organisations(Id),
    FOREIGN KEY (RoleId) REFERENCES Roles(Id)
);

--Branches table
CREATE TABLE Branches (
    Id INT PRIMARY KEY AUTO_INCREMENT,
    OrganisationId INT,
    City VARCHAR(255),
    FOREIGN KEY (OrganisationId) REFERENCES Organisations(Id)
);

--BranchManagers table
CREATE TABLE BranchManagers (
    Id INT PRIMARY KEY AUTO_INCREMENT,
    BranchId INT,
    OrganisationUserId INT,
    FOREIGN KEY (BranchId) REFERENCES Branches(Id),
    FOREIGN KEY (OrganisationUserId) REFERENCES OrganisationUsers(Id)
);

--NotificationTypes table
CREATE TABLE NotificationTypes (
    Id INT PRIMARY KEY AUTO_INCREMENT,
    Name VARCHAR(255)
);

--OrganisationNotificationTypes table
CREATE TABLE OrganisationNotificationTypes (
    Id INT PRIMARY KEY AUTO_INCREMENT,
    OrganisationId INT,
    NotificationTypeId INT,
    Name VARCHAR(255),
    FOREIGN KEY (OrganisationId) REFERENCES Organisations(Id),
    FOREIGN KEY (NotificationTypeId) REFERENCES NotificationTypes(Id)
);

--OrganisationMembershipNotificationTypes table
CREATE TABLE OrganisationMembershipNotificationTypes (
    Id INT PRIMARY KEY AUTO_INCREMENT,
    OrganisationUserId INT,
    OrganisationNotificationTypeId INT,
    FOREIGN KEY (OrganisationUserId) REFERENCES OrganisationUsers(Id),
    FOREIGN KEY (OrganisationNotificationTypeId) REFERENCES OrganisationNotificationTypes(Id)
);

--Announcements table
CREATE TABLE Announcements (
    Id INT PRIMARY KEY AUTO_INCREMENT,
    OrganisationId INT,
    IsPublic BOOLEAN,
    Title VARCHAR(255),
    Content TEXT,
    TimeCreated DATETIME,
    FOREIGN KEY (OrganisationId) REFERENCES Organisations(Id)
);

--Events table
CREATE TABLE Events (
    Id INT PRIMARY KEY AUTO_INCREMENT,
    OrganisationId INT,
    Name VARCHAR(255),
    Description TEXT,
    TimeOfEvent DATETIME,
    Location VARCHAR(255),
    FOREIGN KEY (OrganisationId) REFERENCES Organisations(Id)
);

--RSVPs table
CREATE TABLE RSVPs (
    Id INT PRIMARY KEY AUTO_INCREMENT,
    OrganisationUserId INT,
    EventId INT,
    FOREIGN KEY (OrganisationUserId) REFERENCES OrganisationUsers(Id),
    FOREIGN KEY (EventId) REFERENCES Events(Id)
);