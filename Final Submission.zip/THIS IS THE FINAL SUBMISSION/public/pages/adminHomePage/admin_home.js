document.addEventListener('DOMContentLoaded', () => {
  loadPosts();
  loadEvents();
});

function loadPosts() {
  const posts = ['POST 1', 'POST 2', 'POST 3'];
  const postsList = document.getElementById('posts-list');
  posts.forEach(post => {
      const postItem = document.createElement('div');
      postItem.className = 'menu-item';
      postItem.innerHTML = `
          ${post} <button class="edit-button" onclick="editPost('${post}')">Edit</button> <button class="delete-button" onclick="deletePost('${post}')">Delete</button>
      `;
      postsList.appendChild(postItem);
  });
}

function loadEvents() {
  const events = ['EVENT 1', 'EVENT 2', 'EVENT 3'];
  const eventsList = document.getElementById('events-list');
  events.forEach(event => {
      const eventItem = document.createElement('div');
      eventItem.className = 'menu-item';
      eventItem.innerHTML = `
          ${event} <button class="edit-button" onclick="editEvent('${event}')">Edit</button> <button class="delete-button" onclick="deleteEvent('${event}')">Delete</button>
      `;
      eventsList.appendChild(eventItem);
  });
}

function editPost(post) {
  const newPost = prompt(`Edit post: ${post}`);
  if (newPost) {
      const postsList = document.getElementById('posts-list');
      const postItem = Array.from(postsList.children).find(item => item.textContent.includes(post));
      postItem.innerHTML = `
          ${newPost} <button class="edit-button" onclick="editPost('${newPost}')">Edit</button> <button class="delete-button" onclick="deletePost('${newPost}')">Delete</button>
      `;
  }
}

function deletePost(post) {
  if (confirm(`Are you sure you want to delete "${post}"?`)) {
      const postsList = document.getElementById('posts-list');
      const postItem = Array.from(postsList.children).find(item => item.textContent.includes(post));
      postsList.removeChild(postItem);
  }
}

function editEvent(event) {
  const newEvent = prompt(`Edit event: ${event}`);
  if (newEvent) {
      const eventsList = document.getElementById('events-list');
      const eventItem = Array.from(eventsList.children).find(item => item.textContent.includes(event));
      eventItem.innerHTML = `
          ${newEvent} <button class="edit-button" onclick="editEvent('${newEvent}')">Edit</button> <button class="delete-button" onclick="deleteEvent('${newEvent}')">Delete</button>
      `;
  }
}

function deleteEvent(event) {
  if (confirm(`Are you sure you want to delete "${event}"?`)) {
      const eventsList = document.getElementById('events-list');
      const eventItem = Array.from(eventsList.children).find(item => item.textContent.includes(event));
      eventsList.removeChild(eventItem);
  }
}