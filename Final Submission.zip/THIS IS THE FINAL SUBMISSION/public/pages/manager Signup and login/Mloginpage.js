// // new Vue({
// //     el: '#app',
// //     data: {
// //         emailOrUsername: '',
// //         password: '',
// //         errors: []
// //     },
// //     methods: {
// //         checkLogin: function() {
// //             const user = {
// //                 email: "dil.singh@gmail.com",
// //                 username: "dil01",
// //                 password: "pass"
// //             };
// //             this.errors = [];
// //             if (!this.emailOrUsername) {
// //                 this.errors.push('Email or Username required.');
// //             }
// //             if (!this.password) {
// //                 this.errors.push('Password required.');
// //             }
// //             if (!this.errors.length) {
// //                 if ((this.emailOrUsername === user.email || this.emailOrUsername === user.username) && this.password === user.password) {
// //                     alert('Login successful');
// //                     window.location.href = 'Home.html';
// //                 } else {
// //                     this.errors.push('Invalid email/username or password.');
// //                 }
// //             }
// //         }
// //     }
// //   });

// Initialize Firebase
const firebaseConfig = {
    apiKey: "AIzaSyBjENQMFFtNd9F1ZzVubeiEG9iw-j3Oweg",
    authDomain: "register-58422.firebaseapp.com",
    databaseURL: "https://register-58422-default-rtdb.firebaseio.com",
    projectId: "register-58422",
    storageBucket: "register-58422.appspot.com",
    messagingSenderId: "700719456723",
    appId: "1:700719456723:web:94456129b3afa5aae84f26",
    measurementId: "G-FVB37G3RWT"
};

firebase.initializeApp(firebaseConfig);

new Vue({
    el: '#app',
    data: {
        emailOrUsername: '',
        password: '',
        errors: []
    },
    methods: {
        checkLogin: function() {
            this.errors = [];
            if (!this.emailOrUsername) {
                this.errors.push('Email or Username required.');
            }
            if (!this.password) {
                this.errors.push('Password required.');
            }
            if (!this.errors.length) {
                // Check if the input is an email or username
                if (this.emailOrUsername.includes('@')) {
                    // Login with email and password
                    firebase.auth().signInWithEmailAndPassword(this.emailOrUsername, this.password)
                        .then((userCredential) => {
                            // Login successful
                            alert('Login successful');
                            window.location.href = 'Home.html';
                        })
                        .catch((error) => {
                            var errorMessage = this.getFirebaseErrorMessage(error);
                            this.errors.push(errorMessage);
                        });
                } else {
                    // Login with username and password
                    firebase.database().ref('users').orderByChild('username').equalTo(this.emailOrUsername).once('value')
                        .then((snapshot) => {
                            if (snapshot.exists()) {
                                const userData = snapshot.val();
                                const userEmail = Object.values(userData)[0].email;
                                return firebase.auth().signInWithEmailAndPassword(userEmail, this.password);
                            } else {
                                throw new Error('Invalid username or password.');
                            }
                        })
                        .then((userCredential) => {
                            // Login successful
                            alert('Login successful');
                            window.location.href = 'Home.html';
                        })
                        .catch((error) => {
                            var errorMessage = this.getFirebaseErrorMessage(error);
                            this.errors.push(errorMessage);
                        });
                }
            }
        },
        signInWithGoogle: function() {
            const provider = new firebase.auth.GoogleAuthProvider();
            firebase.auth().signInWithPopup(provider)
                .then((result) => {
                    // Google login successful
                    alert('Login successful');
                    window.location.href = 'Home.html';
                })
                .catch((error) => {
                    var errorMessage = this.getFirebaseErrorMessage(error);
                    this.errors.push(errorMessage);
                });
        },
        getFirebaseErrorMessage: function(error) {
            var errorCode = error.code;
            var errorMessage = error.message;
            if (errorCode === 'auth/user-not-found') {
                return 'User not found. Please check your email or username.';
            } else if (errorCode === 'auth/wrong-password') {
                return 'Wrong password. Please try again.';
            } else {
                return 'Wrong email or password. Please try again.'; // Fallback for other Firebase errors
            }
        }
    }
});
