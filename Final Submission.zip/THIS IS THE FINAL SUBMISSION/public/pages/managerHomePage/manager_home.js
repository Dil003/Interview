document.addEventListener('DOMContentLoaded', () => {
  loadPosts();
  loadEvents();
  loadUsers();
});

function loadPosts() {
  const posts = ['POST 1', 'POST 2', 'POST 3'];
  const postsList = document.getElementById('posts-list');
  posts.forEach(post => {
      const postItem = document.createElement('div');
      postItem.className = 'menu-item';
      postItem.innerHTML = `
          ${post} <button class="edit-button" onclick="editPost('${post}')">Edit</button> <button class="delete-button" onclick="deletePost('${post}')">Delete</button>
      `;
      postsList.appendChild(postItem);
  });
}

function loadEvents() {
  const events = ['EVENT 1', 'EVENT 2', 'EVENT 3'];
  const eventsList = document.getElementById('events-list');
  events.forEach(event => {
      const eventItem = document.createElement('div');
      eventItem.className = 'menu-item';
      eventItem.innerHTML = `
          ${event} <button class="edit-button" onclick="editEvent('${event}')">Edit</button> <button class="delete-button" onclick="deleteEvent('${event}')">Delete</button>
      `;
      eventsList.appendChild(eventItem);
  });
}

function loadUsers() {
  const users = ['@DilrajveerSingh', '@User2', '@User3'];
  const usersList = document.getElementById('users-list');
  users.forEach(user => {
      const userItem = document.createElement('div');
      userItem.className = 'menu-item';
      userItem.innerHTML = `
          <a href="/profile"><img class="icon" src="/figures/${user}.jpeg" alt="User Avatar"></a>
          <p class="username">${user}</p>
          <button class="edit-button" onclick="editUser('${user}')">Edit</button>
          <button class="delete-button" onclick="deleteUser('${user}')">Delete</button>
      `;
      usersList.appendChild(userItem);
  });
}

function addPost() {
  const newPost = prompt('Enter new post:');
  if (newPost) {
      const postsList = document.getElementById('posts-list');
      const postItem = document.createElement('div');
      postItem.className = 'menu-item';
      postItem.innerHTML = `
          ${newPost} <button class="edit-button" onclick="editPost('${newPost}')">Edit</button> <button class="delete-button" onclick="deletePost('${newPost}')">Delete</button>
      `;
      postsList.appendChild(postItem);
  }
}

function editPost(post) {
  const newPost = prompt(`Edit post: ${post}`);
  if (newPost) {
      const postsList = document.getElementById('posts-list');
      const postItem = Array.from(postsList.children).find(item => item.textContent.includes(post));
      postItem.innerHTML = `
          ${newPost} <button class="edit-button" onclick="editPost('${newPost}')">Edit</button> <button class="delete-button" onclick="deletePost('${newPost}')">Delete</button>
      `;
  }
}

function deletePost(post) {
  if (confirm(`Are you sure you want to delete "${post}"?`)) {
      const postsList = document.getElementById('posts-list');
      const postItem = Array.from(postsList.children).find(item => item.textContent.includes(post));
      postsList.removeChild(postItem);
  }
}

function addEvent() {
  const newEvent = prompt('Enter new event:');
  if (newEvent) {
      const eventsList = document.getElementById('events-list');
      const eventItem = document.createElement('div');
      eventItem.className = 'menu-item';
      eventItem.innerHTML = `
          ${newEvent} <button class="edit-button" onclick="editEvent('${newEvent}')">Edit</button> <button class="delete-button" onclick="deleteEvent('${newEvent}')">Delete</button>
      `;
      eventsList.appendChild(eventItem);
  }
}

function editEvent(event) {
  const newEvent = prompt(`Edit event: ${event}`);
  if (newEvent) {
      const eventsList = document.getElementById('events-list');
      const eventItem = Array.from(eventsList.children).find(item => item.textContent.includes(event));
      eventItem.innerHTML = `
          ${newEvent} <button class="edit-button" onclick="editEvent('${newEvent}')">Edit</button> <button class="delete-button" onclick="deleteEvent('${newEvent}')">Delete</button>
      `;
  }
}

function deleteEvent(event) {
  if (confirm(`Are you sure you want to delete "${event}"?`)) {
      const eventsList = document.getElementById('events-list');
      const eventItem = Array.from(eventsList.children).find(item => item.textContent.includes(event));
      eventsList.removeChild(eventItem);
  }
}

function editUser(user) {
  const newUser = prompt(`Edit user: ${user}`);
  if (newUser) {
      const usersList = document.getElementById('users-list');
      const userItem = Array.from(usersList.children).find(item => item.textContent.includes(user));
      userItem.innerHTML = `
          <a href="/profile"><img class="icon" src="/figures/${newUser}.jpeg" alt="User Avatar"></a>
          <p class="username">${newUser}</p>
          <button class="edit-button" onclick="editUser('${newUser}')">Edit</button>
          <button class="delete-button" onclick="deleteUser('${newUser}')">Delete</button>
      `;
  }
}

function deleteUser(user) {
  if (confirm(`Are you sure you want to delete "${user}"?`)) {
      const usersList = document.getElementById('users-list');
      const userItem = Array.from(usersList.children).find(item => item.textContent.includes(user));
      usersList.removeChild(userItem);
  }
}