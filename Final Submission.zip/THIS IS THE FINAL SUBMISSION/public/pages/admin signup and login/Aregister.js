// // Initialize Firebase
// const firebaseConfig = {
//     apiKey: "AIzaSyBjENQMFFtNd9F1ZzVubeiEG9iw-j3Oweg",
//     authDomain: "register-58422.firebaseapp.com",
//     databaseURL: "https://register-58422-default-rtdb.firebaseio.com",
//     projectId: "register-58422",
//     storageBucket: "register-58422.appspot.com",
//     messagingSenderId: "700719456723",
//     appId: "1:700719456723:web:94456129b3afa5aae84f26",
//     measurementId: "G-FVB37G3RWT"
// };

// firebase.initializeApp(firebaseConfig);

// new Vue({
//     el: '#app',
//     data: {
//         username: '',
//         email: '',
//         password: '',
//         errors: []
//     },
//     methods: {
//         isValidEmail: function(email) {
//             var re = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@(([^<>()[\]\.,;:\s@"]+\.)+[^<>()[\]\.,;:\s@"]{2,})$/i;
//             return re.test(String(email).toLowerCase());
//         },
//         checkRegister: function() {
//             this.errors = [];
//             if (!this.username) {
//                 this.errors.push('Username required.');
//             } else if (this.username.length < 4) {
//                 this.errors.push('Username must be at least 4 characters long.');
//             }
//             if (!this.email) {
//                 this.errors.push('Email required.');
//             } else if (!this.isValidEmail(this.email)) {
//                 this.errors.push('Valid email required.');
//             }
//             if (!this.password) {
//                 this.errors.push('Password required.');
//             } else if (this.password.length < 6) {
//                 this.errors.push('Password must be at least 6 characters long.');
//             }
//             if (!this.errors.length) {
//                 // Perform registration with Firebase
//                 firebase.auth().createUserWithEmailAndPassword(this.email, this.password)
//                     .then((userCredential) => {
//                         // Registration successful
//                         const user = userCredential.user;
//                         // Save additional user data to Realtime Database
//                         firebase.database().ref('users/' + user.uid).set({
//                             username: this.username,
//                             email: this.email
//                         });
//                         alert('Registration successful');
//                         window.location.href = 'admin_home.html';
//                     })
//                     .catch((error) => {
//                         var errorCode = error.code;
//                         var errorMessage = error.message;
//                         if (errorCode === 'auth/email-already-in-use') {
//                             this.errors.push('The email address is already in use. Please login instead.');
//                         } else {
//                             this.errors.push(errorMessage);
//                         }
//                     });
//             }
//         }
//     }
// });






// Initialize Firebase
const firebaseConfig = {
    apiKey: "AIzaSyBjENQMFFtNd9F1ZzVubeiEG9iw-j3Oweg",
    authDomain: "register-58422.firebaseapp.com",
    databaseURL: "https://register-58422-default-rtdb.firebaseio.com",
    projectId: "register-58422",
    storageBucket: "register-58422.appspot.com",
    messagingSenderId: "700719456723",
    appId: "1:700719456723:web:94456129b3afa5aae84f26",
    measurementId: "G-FVB37G3RWT"
};

firebase.initializeApp(firebaseConfig);

new Vue({
    el: '#app',
    data: {
        email: '',
        password: '',
        errors: [],
        registering: false // Flag to track registration process
    },
    methods: {
        isValidEmail: function(email) {
            var re = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@(([^<>()[\]\.,;:\s@"]+\.)+[^<>()[\]\.,;:\s@"]{2,})$/i;
            return re.test(String(email).toLowerCase());
        },
        checkRegister: function() {
            if (this.registering) return; // Prevent multiple registrations
            this.errors = [];
            if (!this.email) {
                this.errors.push('Email required.');
            } else if (!this.isValidEmail(this.email)) {
                this.errors.push('Valid email required.');
            }
            if (!this.password) {
                this.errors.push('Password required.');
            } else if (this.password.length < 6) {
                this.errors.push('Password must be at least 6 characters long.');
            }
            if (!this.errors.length) {
                this.registering = true; // Set flag to indicate registration in progress
                // Perform registration with Firebase
                firebase.auth().createUserWithEmailAndPassword(this.email, this.password)
                    .then((userCredential) => {
                        // Registration successful
                        const user = userCredential.user;
                        // Save additional user data to Realtime Database
                        firebase.database().ref('users/' + user.uid).set({
                            email: this.email
                        });
                        alert('Registration successful');
                        window.location.href = 'admin_home.html';
                    })
                    .catch((error) => {
                        var errorCode = error.code;
                        var errorMessage = error.message;
                        if (errorCode === 'auth/email-already-in-use') {
                            this.errors.push('The email address is already in use. Please login instead.');
                        } else {
                            this.errors.push(errorMessage);
                        }
                    })
                    .finally(() => {
                        this.registering = false; // Reset registration flag
                    });
            }
        }
    }
});
