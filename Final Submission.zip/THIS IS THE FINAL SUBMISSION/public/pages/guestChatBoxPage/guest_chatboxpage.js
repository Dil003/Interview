function showContent(id) {
  const contents = document.querySelectorAll('.content');
  contents.forEach(content => {
      content.classList.remove('active');
  });
  document.getElementById(id).classList.add('active');
}

function sendMessage() {
  const input = document.getElementById('messageInput');
  const message = input.value.trim();
  if (message) {
      const messageContainer = document.createElement('div');
      messageContainer.classList.add('comment');
      messageContainer.innerHTML = `
          <img src="/public/figures/avatar1.jpg" alt="User Avatar" class="avatar">
          <div class="message-content">
              <p><strong>You <span class="timestamp">${new Date().toLocaleTimeString()}</span></strong></p>
              <p>${message}</p>
          </div>
      `;
      document.querySelector('.main-content .content.active').appendChild(messageContainer);
      input.value = '';
  }
}