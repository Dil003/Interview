document.addEventListener('DOMContentLoaded', () => {
    const rsvpButtons = document.querySelectorAll('.action-button');
    rsvpButtons.forEach(button => {
        button.addEventListener('click', () => {
            if (button.textContent.includes('RSVP') || button.textContent.includes('Volunteer Joined') || button.textContent.includes('Volunteer Quit')) {
                alert(`${button.textContent} button clicked!`);
            } else {
                const action = button.textContent.includes('✘') ? 'Rejected' : 'Accepted';
                alert(`${button.parentElement.querySelector('p').textContent} ${action}`);
            }
        });
    });
    const createPostButton = document.querySelector('.create-post .action-button');
    createPostButton.addEventListener('click', () => {
        const postDetails = document.querySelector('.create-post .textarea').value;
        if (postDetails) {
            alert(`Post created: ${postDetails}`);
            document.querySelector('.create-post .textarea').value = '';
        } else {
            alert('Please enter post details.');
        }
    });

    const createEventButton = document.querySelector('.create-event .action-button');
    createEventButton.addEventListener('click', () => {
        const eventDetails = document.querySelector('.create-event .textarea').value;
        if (eventDetails) {
            alert(`Event created: ${eventDetails}`);
            document.querySelector('.create-event .textarea').value = '';
        } else {
            alert('Please enter event details.');
        }
    });
});
