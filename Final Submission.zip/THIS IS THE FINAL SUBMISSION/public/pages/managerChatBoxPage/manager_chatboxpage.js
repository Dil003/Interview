function showContent(id) {
  const contents = document.querySelectorAll('.content');
  contents.forEach(content => {
      content.classList.remove('active');
  });
  document.getElementById(id).classList.add('active');
}

function sendMessage() {
  const input = document.getElementById('messageInput');
  const message = input.value.trim();
  if (message) {
      const messageContainer = document.createElement('div');
      messageContainer.classList.add('comment');
      messageContainer.innerHTML = `
          <div class="admin-buttons">
              <button class="admin-button delete-button">&times;</button>
              <button class="admin-button highlight-button">&#9733;</button>
              <button class="admin-button edit-button">&#9998;</button>
              <button class="admin-button role-button">R</button>
          </div>
          <img src="/public/figures/avatar1.jpg" alt="User Avatar" class="avatar">
          <div class="message-content">
              <p><strong>You <span class="timestamp">${new Date().toLocaleTimeString()}</span></strong></p>
              <p>${message}</p>
          </div>
      `;
      document.querySelector('.main-content .content.active').appendChild(messageContainer);
      input.value = '';

      // Add event listeners to the new buttons
      messageContainer.querySelector('.delete-button').addEventListener('click', () => {
          messageContainer.remove();
      });
      messageContainer.querySelector('.highlight-button').addEventListener('click', () => {
          messageContainer.querySelector('.message-content').classList.toggle('highlighted');
      });
      messageContainer.querySelector('.edit-button').addEventListener('click', () => {
          editMessage(messageContainer.querySelector('.message-content'));
      });
      messageContainer.querySelector('.role-button').addEventListener('click', () => {
          assignRole(messageContainer);
      });
  }
}

function editMessage(messageContent) {
  if (messageContent.classList.contains('edit-mode')) {
      // Save the changes
      const textarea = messageContent.querySelector('textarea');
      const newText = textarea.value;
      messageContent.innerHTML = `<p>${newText}</p>`;
      messageContent.classList.remove('edit-mode');
  } else {
      // Enter edit mode
      const text = messageContent.innerText;
      messageContent.innerHTML = `<textarea>${text}</textarea>`;
      messageContent.classList.add('edit-mode');
  }
}

function assignRole(messageContainer) {
  const role = prompt('Enter the role to assign:');
  if (role) {
      const roleBadge = document.createElement('span');
      roleBadge.classList.add('role-badge');
      roleBadge.innerText = role;
      messageContainer.appendChild(roleBadge);
  }
}

document.querySelectorAll('.delete-button').forEach(button => {
  button.addEventListener('click', function() {
      this.parentElement.parentElement.remove();
  });
});

document.querySelectorAll('.highlight-button').forEach(button => {
  button.addEventListener('click', function() {
      this.parentElement.nextElementSibling.classList.toggle('highlighted');
  });
});

document.querySelectorAll('.edit-button').forEach(button => {
  button.addEventListener('click', function() {
      editMessage(this.parentElement.nextElementSibling);
  });
});

document.querySelectorAll('.role-button').forEach(button => {
  button.addEventListener('click', function() {
      assignRole(this.parentElement.parentElement);
  });
});