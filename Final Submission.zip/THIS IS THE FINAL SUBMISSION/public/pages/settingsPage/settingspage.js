document.addEventListener('DOMContentLoaded', () => {
    

    const signOutItem = document.getElementById('sign-out');
    signOutItem.addEventListener('click', () => {
        alert('You have signed out!');
    });

    const aboutUsItem = document.getElementById('about-us');
    aboutUsItem.addEventListener('click', () => {
        alert('We are Volunify, committed to connecting volunteers with meaningful causes.');
    });

    const goBackItem = document.getElementById('go-back');
    signOutItem.addEventListener('click', () => {
    });
});