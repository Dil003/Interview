document.addEventListener('DOMContentLoaded', () => {
    const avatars = {
        user1: 'avatar1.png',
        user2: 'avatar2.png',
        user3: 'avatar3.png'
    };

    const organizations = [
        'GrowTree',
        'TreeLovers',
        'GreenEarth'
    ];

    const events = [
        'Planting Session - April 10',
        'Tree Maintenance - April 12',
        'Community Meeting - April 15'
    ];

    const orgSelect = document.querySelector('select#org-dropdown');
    organizations.forEach(org => {
        const option = document.createElement('option');
        option.value = org;
        option.textContent = org;
        orgSelect.appendChild(option);
    });

    const eventSelect = document.querySelector('select#event-dropdown');
    events.forEach(event => {
        const option = document.createElement('option');
        option.value = event;
        option.textContent = event;
        eventSelect.appendChild(option);
    });

    orgSelect.addEventListener('change', (event) => {
        alert(`Joined organization: ${event.target.value}`);
    });

    eventSelect.addEventListener('change', (event) => {
        alert(`RSVP'd for event: ${event.target.value}`);
    });

    const friends = [
        { username: '@DilrajveerSingh', avatar: '/figures/avatar1.jpeg' },
        { username: '@AntonBadalian', avatar: '/figures/avatar2.jpg' },
        { username: '@RhettCalnan', avatar: '/figures/avatar3.jpg' }
    ];

    const friendsList = document.querySelector('.friends-list');
    friends.forEach(friend => {
        const listItem = document.createElement('li');
        const img = document.createElement('img');
        img.src = friend.avatar;
        img.alt = 'Friend Avatar';
        img.classList.add('avatar');
        listItem.appendChild(img);
        const text = document.createTextNode(friend.username);
        listItem.appendChild(text);
        friendsList.appendChild(listItem);
    });
});