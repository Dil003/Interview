const express = require('express');
const path = require('path');
const cookieParser = require('cookie-parser');
const logger = require('morgan');

// routes
const pagesRouter = require('./src/routes/pages');

// configuration
const setupDatabase = require('./src/configuration/setupDatabase');
const setupFirebase = require('./src/configuration/setupFirebase');
const setupSessions = require('./src/configuration/setupSessions');

// controllers
const authenticationController = require('./src/features/authentication/controller/authenticationController');
const usersController = require('./src/features/users/controller/usersController');
const organisationController = require('./src/features/organisation/controller/organisationController');
const adminController = require('./src/features/admin/controller/adminController');
const setupPages = require('./src/configuration/setupPages');

const app = express();

app.use(logger('dev'));
app.use(express.json());
app.use(express.urlencoded({ extended: false }));
app.use(cookieParser());
app.use(express.static(path.join(__dirname, 'public')));

// routes
app.use('/', pagesRouter);

// setup pages
let pagePath = path.join(__dirname, 'public', 'pages');
app.locals.pagePath = pagePath;
setupPages(app);

// middleswares

// configuration
setupDatabase(app);
setupFirebase(app);
setupSessions(app);

// controllers
app.use('/api/auth', authenticationController);
app.use('/api/users', usersController);
app.use('/api/organisation', organisationController);
app.use('/api/admin', adminController);

module.exports = app;
