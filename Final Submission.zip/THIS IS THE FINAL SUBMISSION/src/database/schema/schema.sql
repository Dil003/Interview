# Create database
CREATE DATABASE IF NOT EXISTS WDCProject;
USE WDCProject;

# Drop tables if they already exist
DROP TABLE IF EXISTS RSVPs;
DROP TABLE IF EXISTS Events;
DROP TABLE IF EXISTS Announcements;
DROP TABLE IF EXISTS OrganisationMembershipNotificationTypes;
DROP TABLE IF EXISTS OrganisationNotificationTypes;
DROP TABLE IF EXISTS NotificationTypes;
DROP TABLE IF EXISTS BranchManagers;
DROP TABLE IF EXISTS Branches;
DROP TABLE IF EXISTS OrganisationUsers;
DROP TABLE IF EXISTS Organisations;
DROP TABLE IF EXISTS UserRoles;
DROP TABLE IF EXISTS Roles;
DROP TABLE IF EXISTS Users;

# Organisations table
CREATE TABLE Organisations (
    Id INT PRIMARY KEY AUTO_INCREMENT,
    Name VARCHAR(255),
    Description TEXT,
    Likes INT,
    Visits INT,
    Favorites INT,
    Conversions INT,
    Views INT,
    Members INT,
    Established DATE,
    UNIQUE (Name)
);

# Users table
CREATE TABLE Users (
    Id INT PRIMARY KEY AUTO_INCREMENT,
    AuthenticationType VARCHAR(255),
    FirstName VARCHAR(255),
    LastName VARCHAR(255),
    Email VARCHAR(255),
    Username VARCHAR(255),
    AccountSetup BOOLEAN,
    PhoneNumber VARCHAR(20),
    City VARCHAR(255),
    DateOfBirth DATE,
    Twitter VARCHAR(255),
    Facebook VARCHAR(255),
    Instagram VARCHAR(255),
    UNIQUE (Email),
    UNIQUE (Username)
);

# Roles table
CREATE TABLE Roles (
    Id INT PRIMARY KEY AUTO_INCREMENT,
    Name VARCHAR(255),
    UNIQUE (Name)
);

# UserRoles table
CREATE TABLE UserRoles (
    Id INT PRIMARY KEY AUTO_INCREMENT,
    UserId INT,
    RoleId INT,
    FOREIGN KEY (UserId) REFERENCES Users(Id) ON DELETE CASCADE,
    FOREIGN KEY (RoleId) REFERENCES Roles(Id),
    UNIQUE (UserId, RoleId)
);

# OrganisationUsers table
CREATE TABLE OrganisationUsers (
    Id INT PRIMARY KEY AUTO_INCREMENT,
    UserId INT,
    OrganisationId INT,
    RoleId INT,
    FOREIGN KEY (UserId) REFERENCES Users(Id) ON DELETE CASCADE,
    FOREIGN KEY (OrganisationId) REFERENCES Organisations(Id),
    FOREIGN KEY (RoleId) REFERENCES Roles(Id)
    UNIQUE (UserId, OrganisationId)
);

# Branches table
CREATE TABLE Branches (
    Id INT PRIMARY KEY AUTO_INCREMENT,
    OrganisationId INT,
    City VARCHAR(255),
    FOREIGN KEY (OrganisationId) REFERENCES Organisations(Id),
    UNIQUE (City)
);

# BranchManagers table
CREATE TABLE BranchManagers (
    Id INT PRIMARY KEY AUTO_INCREMENT,
    BranchId INT,
    UserId INT,
    FOREIGN KEY (BranchId) REFERENCES Branches(Id),
    FOREIGN KEY (UserId) REFERENCES Users(Id) ON DELETE CASCADE,
    UNIQUE (BranchId, UserId)
);

# NotificationTypes table
CREATE TABLE NotificationTypes (
    Id INT PRIMARY KEY AUTO_INCREMENT,
    Name VARCHAR(255),
    UNIQUE (Name)
);

# OrganisationNotificationTypes table
CREATE TABLE OrganisationNotificationTypes (
    Id INT PRIMARY KEY AUTO_INCREMENT,
    OrganisationId INT,
    NotificationTypeId INT,
    Name VARCHAR(255),
    FOREIGN KEY (OrganisationId) REFERENCES Organisations(Id),
    FOREIGN KEY (NotificationTypeId) REFERENCES NotificationTypes(Id)
);

# OrganisationMembershipNotificationTypes table
CREATE TABLE OrganisationMembershipNotificationTypes (
    Id INT PRIMARY KEY AUTO_INCREMENT,
    OrganisationUserId INT,
    OrganisationNotificationTypeId INT,
    FOREIGN KEY (OrganisationUserId) REFERENCES OrganisationUsers(Id),
    FOREIGN KEY (OrganisationNotificationTypeId) REFERENCES OrganisationNotificationTypes(Id)
);

# Announcements table
CREATE TABLE Announcements (
    Id INT PRIMARY KEY AUTO_INCREMENT,
    OrganisationId INT,
    IsPublic BOOLEAN,
    Title VARCHAR(255),
    Content TEXT,
    TimeCreated DATETIME,
    FOREIGN KEY (OrganisationId) REFERENCES Organisations(Id)
);

# Events table
CREATE TABLE Events (
    Id INT PRIMARY KEY AUTO_INCREMENT,
    OrganisationId INT,
    Name VARCHAR(255),
    Description TEXT,
    TimeOfEvent DATETIME,
    Location VARCHAR(255),
    FOREIGN KEY (OrganisationId) REFERENCES Organisations(Id)
);

# RSVPs table
CREATE TABLE RSVPs (
    Id INT PRIMARY KEY AUTO_INCREMENT,
    UserId INT,
    EventId INT,
    FOREIGN KEY (UserId) REFERENCES Users(Id) ON DELETE CASCADE,
    FOREIGN KEY (EventId) REFERENCES Events(Id),
    UNIQUE (UserId, EventId)
);

# Add Organisation
INSERT INTO Organisations (Name, Description, Likes, Visits, Favorites, Conversions, Views, Members, Established)
VALUES ('GrowTree', 'A team for planting trees around Australia!', 152, 1230, 65, 10, 2200, 200, '2024-04-11');

# Add Roles
INSERT INTO Roles (Name) VALUES ('Admin'), ('Member'), ('Manager');

# Add Admin
INSERT INTO Users (AuthenticationType, FirstName, LastName, Email, Username, AccountSetup, PhoneNumber, City, DateOfBirth, Twitter, Facebook, Instagram)
Values ('Default', 'Anton', 'Badalian', 'badaliananton@gmail.com', 'anton15b', true, '0406312347', 'Adelaide', '2003-01-01', 'anton15b', 'anton15b', 'anton15b');

INSERT INTO UserRoles (UserId, RoleId)
Values (1, 1);

# Add Test Member
INSERT INTO Users (AuthenticationType, FirstName, LastName, Email, Username, AccountSetup, PhoneNumber, City, DateOfBirth, Twitter, Facebook, Instagram)
Values ('Default', 'John', 'Doe', 'randomEmail@test.com', 'john', true, '0406312347', 'Adelaide', '2003-01-01', 'john', 'john', 'john');

INSERT INTO UserRoles (UserId, RoleId)
Values (2, 2);