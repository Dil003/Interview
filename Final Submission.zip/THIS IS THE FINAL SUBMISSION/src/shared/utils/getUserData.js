async function getUserData(userId, req) {
  const [rows] = await req.pool.query("SELECT * FROM Users AS u WHERE u.Id = ?", [userId]);

  return rows;
}