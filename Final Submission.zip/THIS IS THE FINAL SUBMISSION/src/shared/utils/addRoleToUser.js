const getRoleIdByName = require("./getRoleIdByName");

async function addRoleToUser(userId, roleName, req) {

  const roleId = await getRoleIdByName(roleName, req);

  const [result] = await req.pool.query(`
    INSERT INTO UserRoles (UserId, RoleId)
    VALUES (?, ?)
  `, [userId, roleId]);

}

module.exports = addRoleToUser;