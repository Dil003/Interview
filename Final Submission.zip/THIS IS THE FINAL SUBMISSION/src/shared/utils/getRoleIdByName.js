async function getRoleIdByName(name, req) {
  const [roles] = await req.pool.query(`
    SELECT * FROM Roles WHERE Name = ?
  `, [name]);

  const roleId = roles[0].Id;

  return roleId;
}

module.exports = getRoleIdByName;