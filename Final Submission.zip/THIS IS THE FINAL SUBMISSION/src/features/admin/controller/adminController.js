const express = require('express');
const router = express.Router();

const authorize = require('../../../middlewares/authorizationMiddleware');

const addAdminFeature = require('../addAdminFeature');
const removeUserFeature = require('../removeUserFeature');
const getUsersFeature = require('../getUsersFeature');
const addBranchFeature = require('../addBranchFeature');
const addBranchManagerFeature = require('../addBranchManager');

router.post('/add', authorize(["Admin"]), async function(req, res, next) {
  try {
    let result = await addAdminFeature(req, res, next);

    res.send(result);
  } catch (error) {
    res.sendStatus(400);
  }

});

router.delete('/user', authorize(["Admin"]), async function(req, res, next) {
  try {
    let result = await removeUserFeature(req, res, next);

    res.send(result);
  } catch (error) {
    res.sendStatus(400);
  }

});

router.get('/users', authorize(["Admin"]), async function(req, res, next) {
  try {
    let result = await getUsersFeature(req, res, next);

    res.send(result);
  } catch (error) {
    res.sendStatus(400);
  }

});

router.post('/branch', authorize(["Admin"]), async function(req, res, next) {
  try {
    let result = await addBranchFeature(req, res, next);

    res.send(result);
  } catch (error) {
    res.sendStatus(400);
  }

});

router.post('/branchManager', authorize(["Admin"]), async function(req, res, next) {
  try {
    let result = await addBranchManagerFeature(req, res, next);

    res.send(result);
  } catch (error) {
    res.sendStatus(400);
  }

});

module.exports = router;