const express = require('express');

async function addBranchFeature(req, res, next) {

  try {
    const [result] = await req.pool.query(`
      INSERT INTO Branches (OrganisationId, City)
      VALUES (?, ?)
    `, [1, req.body.City]);

    const [branches] = await req.pool.query(`
      SELECT * FROM Branches
      WHERE Id = ?
    `, [result.insertId]);

    return branches[0];
  } catch (error) {
    res.sendStatus(400);
    return;
  }

}


module.exports = addBranchFeature;