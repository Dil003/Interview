const express = require('express');
const addRoleToUser = require('../../shared/utils/addRoleToUser');

async function addAdminFeature(req, res, next) {

  const userId = req.body.UserId;

  await addRoleToUser(userId, "Admin", req);

  return {};
}


module.exports = addAdminFeature;