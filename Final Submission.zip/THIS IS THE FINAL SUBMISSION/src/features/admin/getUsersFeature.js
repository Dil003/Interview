const express = require('express');

async function getUsersFeature(req, res, next) {

  try {
    const [users] = await req.pool.query(`
      SELECT * FROM Users ORDER BY Id
    `);

    return users.map(user => ({
      Id: user.Id,
      FirstName: user.FirstName,
      LastName: user.LastName,
      Username: user.Username,
      Email: user.Email
    }));
  } catch (error) {
    res.sendStatus(400);
    return;
  }
}


module.exports = getUsersFeature;