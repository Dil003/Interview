const express = require('express');
const addRoleToUser = require('../../shared/utils/addRoleToUser');

async function addBranchManagerFeature(req, res, next) {

  const userId = req.body.UserId;
  const branchId = req.body.BranchId;

  try {
    await addRoleToUser(userId, "Manager", req);

    const [result] = await req.pool.query(`
      INSERT INTO BranchManagers (BranchId, UserId)
      VALUES (?, ?)
    `, [branchId, userId]);
  } catch (error) {
    res.sendStatus(400);
    return;
  }

  return {};
}


module.exports = addBranchManagerFeature;