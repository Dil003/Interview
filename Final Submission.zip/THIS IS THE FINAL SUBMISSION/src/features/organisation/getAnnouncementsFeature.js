
async function getAnnouncementsFeature(req, res, next) {
  let viewPrivateAnnounements = false;

  try {
    if (req.session.userId !== undefined) {
      viewPrivateAnnounements = true;
    }
  } catch (error) {
    //
  }

  try {
    const [announcements] = await req.pool.query(`
      SELECT * FROM Announcements
      ${!viewPrivateAnnounements ? `WHERE IsPublic = true` : ``}
      ORDER BY TimeCreated DESC
    `);

    return announcements;
  } catch (error) {
    res.sendStatus(400);
    return;
  }

}

module.exports = getAnnouncementsFeature;