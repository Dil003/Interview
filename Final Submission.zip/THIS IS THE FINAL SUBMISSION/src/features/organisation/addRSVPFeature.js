const express = require('express');

async function addRSVPFeature(req, res, next) {

  const userId = req.session.userId;

  try {
    const [result] = await req.pool.query(`
      INSERT INTO RSVPs (UserId, EventId)
      VALUES (?, ?)
    `, [userId, req.body.EventId]);

    const [RSVPs] = await req.pool.query(`
      SELECT * FROM RSVPs
      WHERE Id = ?
    `, [result.insertId]);

    return RSVPs[0];
  } catch (error) {
    res.sendStatus(400);
    return;
  }

}


module.exports = addRSVPFeature;