const express = require('express');

async function updateEventFeature(req, res, next) {

  try {
    const [result] = await req.pool.query(`
      UPDATE Events
      SET Name = ?, Description = ?, TimeOfEvent = ?, Location = ?
      WHERE Id = ?
    `, [req.body.Name, req.body.Description, req.body.TimeOfEvent, req.body.Location, req.body.Id]);
  } catch (error) {
    res.sendStatus(400);
    return;
  }

  return {};
}


module.exports = updateEventFeature;