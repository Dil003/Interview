const express = require('express');

async function getEvents(req, res, next) {

  try {
    const [events] = await req.pool.query(`
      SELECT * FROM Events
      WHERE TimeOfEvent > NOW()
      ORDER BY TimeOfEvent
    `);

    return events;
  } catch (error) {
    res.sendStatus(400);
    return;
  }

}


module.exports = getEvents;