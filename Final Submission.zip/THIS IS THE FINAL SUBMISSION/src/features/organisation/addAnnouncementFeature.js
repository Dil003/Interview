
async function addAnnouncementFeature(req, res, next) {

  try {
    const [result] = await req.pool.query(`
      INSERT INTO Announcements (OrganisationId, IsPublic, Title, Content, TimeCreated)
      VALUES (?, ?, ?, ?, ?)
    `, [1, req.body.IsPublic, req.body.Title, req.body.Content, req.body.TimeCreated]);

    const [events] = await req.pool.query(`
      SELECT * FROM Announcements
      WHERE Id = ?
    `, [result.insertId]);

    return events[0];
  } catch (error) {
    res.sendStatus(400);
    return;
  }

}

module.exports = addAnnouncementFeature;