const express = require('express');
const router = express.Router();

const authorize = require('../../../middlewares/authorizationMiddleware');

const getEventsFeature = require('../getEventsFeature');
const addRSVPFeature = require('../addRSVPFeature');
const addEventFeature = require('../addEventFeature');
const updateEventFeature = require('../updateEventFeature');
const getRSVPPeopleFeature = require('../getRSVPPeopleFeature');
const getAnnouncementsFeature = require('../getAnnouncementsFeature');
const addAnnouncementFeature = require('../addAnnouncementFeature');
const updateAnnouncementFeature = require('../updateAnnouncementFeature');
const removeAnnouncementFeature = require('../removeAnnouncementFeature');

router.get('/events', authorize(["Member", "Manager", "Admin"]), async function(req, res, next) {
  try {
    let result = await getEventsFeature(req, res, next);

    res.send(result);
  } catch (error) {
    res.sendStatus(400);
  }

});

router.post('/rsvp', authorize(["Member", "Manager", "Admin"]), async function(req, res, next) {
  try {
    let result = await addRSVPFeature(req, res, next);

    res.send(result);
  } catch (error) {
    res.sendStatus(400);
  }

});

router.post('/event', authorize(["Manager", "Admin"]), async function(req, res, next) {
  try {
    let result = await addEventFeature(req, res, next);

    res.send(result);
  } catch (error) {
    res.sendStatus(400);
  }

});

router.put('/event', authorize(["Manager", "Admin"]), async function(req, res, next) {
  try {
    let result = await updateEventFeature(req, res, next);

    res.send(result);
  } catch (error) {
    res.sendStatus(400);
  }

});

router.get('/rsvpPeople', authorize(["Manager", "Admin"]), async function(req, res, next) {
  try {
    let result = await getRSVPPeopleFeature(req, res, next);

    res.send(result);
  } catch (error) {
    res.sendStatus(400);
  }

});

router.get('/announcements', async function(req, res, next) {
  try {
    let result = await getAnnouncementsFeature(req, res, next);

    res.send(result);
  } catch (error) {
    res.sendStatus(400);
  }

});

router.post('/announcement', authorize(["Manager", "Admin"]), async function(req, res, next) {
  try {
    let result = await addAnnouncementFeature(req, res, next);

    res.send(result);
  } catch (error) {
    res.sendStatus(400);
  }

});

router.put('/announcement', authorize(["Manager", "Admin"]), async function(req, res, next) {
  try {
    let result = await updateAnnouncementFeature(req, res, next);

    res.send(result);
  } catch (error) {
    res.sendStatus(400);
  }

});

router.delete('/announcement', authorize(["Manager", "Admin"]), async function(req, res, next) {
  try {
    let result = await removeAnnouncementFeature(req, res, next);

    res.send(result);
  } catch (error) {
    res.sendStatus(400);
  }

});

module.exports = router;