
async function updateAnnouncementFeature(req, res, next) {

  try {
    const [result] = await req.pool.query(`
      UPDATE Announcements
      SET IsPublic = ?, Title = ?, Content = ?, TimeCreated = ?
      WHERE Id = ?
    `, [req.body.IsPublic, req.body.Title, req.body.Content, req.body.TimeCreated, req.body.Id]);
  } catch (error) {
    res.sendStatus(400);
    return;
  }

  return {};
}

module.exports = updateAnnouncementFeature;