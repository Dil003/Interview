const express = require('express');

async function getRSVPPeopleFeature(req, res, next) {

  try {
    const [users] = await req.pool.query(`
      SELECT u.* FROM Users AS u
      INNER JOIN RSVPs AS r ON r.UserId = u.Id
      WHERE r.EventId = ?
      ORDER BY u.Id
    `, [req.query.EventId]);

    return users.map(user => ({
      Id: user.Id,
      FirstName: user.FirstName,
      LastName: user.LastName,
      Username: user.Username
    }));
  } catch (error) {
    res.sendStatus(400);
    return;
  }

}


module.exports = getRSVPPeopleFeature;