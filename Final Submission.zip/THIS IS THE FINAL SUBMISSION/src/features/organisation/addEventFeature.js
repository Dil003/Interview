const express = require('express');

async function addEventFeature(req, res, next) {

  try {
    const [result] = await req.pool.query(`
      INSERT INTO Events (OrganisationId, Name, Description, TimeOfEvent, Location)
      VALUES (?, ?, ?, ?, ?)
    `, [1, req.body.Name, req.body.Description, req.body.TimeOfEvent, req.body.Location]);

    const [events] = await req.pool.query(`
      SELECT * FROM Events
      WHERE Id = ?
    `, [result.insertId]);

    return events[0];
  } catch (error) {
    res.sendStatus(400);
    return;
  }

}


module.exports = addEventFeature;