
async function removeAnnouncementFeature(req, res, next) {

  const id = req.body.Id;

  try {
    const [result] = await req.pool.query(`
      DELETE FROM Announcements
      WHERE Id = ?
    `, [id]);

    return {};
  } catch (error) {
    res.sendStatus(400);
    return;
  }

}

module.exports = removeAnnouncementFeature;