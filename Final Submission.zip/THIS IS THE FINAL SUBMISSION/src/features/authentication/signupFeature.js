const express = require('express');
const verifyIdToken = require('./shared/verifyIdToken');
const getRoleIdByName = require('../../shared/utils/getRoleIdByName');
const addRoleToUser = require('../../shared/utils/addRoleToUser');

async function signupFeature(req, res, next) {

  const token = await verifyIdToken(req.body.IdToken);
  const email = token.email;

  try {
    const [result] = await req.pool.query(`
      INSERT INTO Users (AuthenticationType, FirstName, LastName, Email, Username, AccountSetup, PhoneNumber, City, DateOfBirth, Twitter, Facebook, Instagram)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `, ["Default", req.body.FirstName, req.body.LastName, email, req.body.Username, true, req.body.PhoneNumber, req.body.City, req.body.DateOfBirth, req.body.Twitter, req.body.Facebook, req.body.Instagram]);

    const userId = result.insertId;

    const memberRoleId = await getRoleIdByName("Member", req);

    await addRoleToUser(userId, memberRoleId, req);

    req.session.userId = userId;
    req.session.roles = ["Member"];
    req.session.save();

  } catch (error) {
    res.sendStatus(400);
    return;
  }

  return {};
}

module.exports = signupFeature;