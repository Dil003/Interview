const { getAuth } = require('firebase-admin/auth');

async function verifyIdToken(idToken) {

  try {
    const uid = await getAuth().verifyIdToken(idToken);

    return uid;
  } catch (error) {
    throw new Error("Failed to verify id token!");
  }

}

module.exports = verifyIdToken;