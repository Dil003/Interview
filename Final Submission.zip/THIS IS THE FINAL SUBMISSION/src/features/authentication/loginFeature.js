const express = require('express');
const verifyIdToken = require('./shared/verifyIdToken');

async function loginFeature(req, res, next) {

  const token = await verifyIdToken(req.body.IdToken);
  const email = token.email;

  try {
    const [users] = await req.pool.query("SELECT * FROM Users AS u WHERE u.Email = ?", [email]);

    const user = users[0];
    const userId = user.Id;

    const [userRoles] = await req.pool.query(`
      SELECT u.*, r.Name FROM UserRoles AS u
      INNER JOIN Roles AS r ON r.Id = u.RoleId
      WHERE u.UserId = ?
    `, [userId]);

    req.session.userId = userId;
    req.session.roles = userRoles.map(role => role.Name);
    req.session.save();
  } catch (error) {
    res.sendStatus(400);
    return;
  }

  return {};
}

module.exports = loginFeature;