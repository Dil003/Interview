const express = require('express');
const router = express.Router();

const signupFeature = require('../signupFeature');
const loginFeature = require('../loginFeature');

const authorize = require('../../../middlewares/authorizationMiddleware');

router.post('/signup', async function(req, res, next) {
  try {
    let result = await signupFeature(req, res, next);

    res.send(result);
  } catch (error) {
    res.sendStatus(400);
  }

});

router.post('/login', async function(req, res, next) {
  try {
    let result = await loginFeature(req, res, next);

    res.send(result);
  } catch (error) {
    res.sendStatus(400);
  }

});

module.exports = router;
