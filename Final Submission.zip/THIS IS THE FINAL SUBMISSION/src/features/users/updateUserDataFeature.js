const express = require('express');

async function updateUserDataFeature(req, res, next) {

  const userId = req.session.userId;

  try {
    const [result] = await req.pool.query(`
      UPDATE Users
      SET FirstName = ?, LastName = ?, PhoneNumber = ?, City = ?, DateOfBirth = ?, Twitter = ?, Facebook = ?, Instagram = ?
      WHERE Id = ?
    `, [req.body.FirstName, req.body.LastName, req.body.PhoneNumber, req.body.City, req.body.DateOfBirth, req.body.Twitter, req.body.Facebook, req.body.Instagram, userId]);
  } catch (error) {
    res.sendStatus(400);
    return;
  }

  return {};
}


module.exports = updateUserDataFeature;