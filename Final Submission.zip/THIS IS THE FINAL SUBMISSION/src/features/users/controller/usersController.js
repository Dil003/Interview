const express = require('express');
const router = express.Router();

const authorize = require('../../../middlewares/authorizationMiddleware');

const getUserDataFeature = require('../getUserDataFeature');
const updateUserDataFeature = require('../updateUserDataFeature');

router.get('/userdata', authorize(["Member", "Manager", "Admin"]), async function(req, res, next) {
  try {
    let result = await getUserDataFeature(req, res, next);

    res.send(result);
  } catch (error) {
    res.sendStatus(400);
  }

});

router.put('/userdata', authorize(["Member", "Manager", "Admin"]), async function(req, res, next) {
  try {
    let result = await updateUserDataFeature(req, res, next);

    res.send(result);
  } catch (error) {
    res.sendStatus(400);
  }

});

module.exports = router;