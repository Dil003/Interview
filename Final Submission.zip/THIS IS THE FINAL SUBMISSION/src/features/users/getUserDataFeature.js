const express = require('express');

async function getUserDataFeature(req, res, next) {

  const userId = req.session.userId;
  console.log(`UserId: ${userId}`);
  try {
    const [rows] = await req.pool.query("SELECT * FROM Users AS u WHERE u.Id = ?", [userId]);

    if (rows.length === 0) {
      res.sendStatus(400);
      return;
    }

    const userData = rows[0];

    return {
      ...userData,
      Roles: req.session.roles
    };
  } catch (error) {
    res.sendStatus(400);
    return;
  }

}


module.exports = getUserDataFeature;