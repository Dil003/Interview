const express = require('express');
const router = express.Router();
const app = require('../../app');
const path = require('path');

const pagePath = path.join(__dirname, '..', '..', 'public', 'pages');

/* GET admin chat box page. */
router.get('/adminChatBox', function(req, res, next) {

  res.sendFile(`${pagePath}/adminChatBoxPage/admin_chatbox.html`);
});

/* GET admin home page. */
router.get('/adminHome', function(req, res, next) {

  res.sendFile(`${pagePath}/adminHomePage/admin_home.html`);
});

/* GET admin profile page. */
router.get('/adminProfile', function(req, res, next) {

  res.sendFile(`${pagePath}/adminProfilePage/admin_profile.html`);
});

/* GET guest chat box page. */
router.get('/guestChatBox', function(req, res, next) {

  res.sendFile(`${pagePath}/guestChatBoxPage/guest_chatboxpage.html`);
});

/* GET guest home page. */
router.get('/guestHome', function(req, res, next) {

  res.sendFile(`${pagePath}/guestHomePage/guest_home.html`);
});

/* GET home page. */
router.get('/guestHome', function(req, res, next) {

  res.sendFile(`${pagePath}/homePage/homepage.html`);
});

/* GET login page. */
router.get('/login', function(req, res, next) {

  res.sendFile(`${pagePath}/loginPage/loginpage.html`);
});

/* GET manager chat box page. */
router.get('/managerChatBox', function(req, res, next) {

  res.sendFile(`${pagePath}/managerChatBoxPage/manager_chatboxpage.html`);
});

/* GET manager home page. */
router.get('/managerHome', function(req, res, next) {

  res.sendFile(`${pagePath}/managerHomePage/manager_home.html`);
});

/* GET notification page. */
router.get('/notifications', function(req, res, next) {

  res.sendFile(`${pagePath}/notificationsPage/notifications.html`);
});

/* GET profile page. */
router.get('/profile', function(req, res, next) {

  res.sendFile(`${pagePath}/profilePage/profilepage.html`);
});

/* GET register page. */
router.get('/register', function(req, res, next) {

  res.sendFile(`${pagePath}/registerPage/registerpage.html`);
});

/* GET settings page. */
router.get('/settings', function(req, res, next) {

  res.sendFile(`${pagePath}/settingsPage/settingspage.html`);
});

/* GET home page. */
router.get('/home', function(req, res, next) {

  // res.sendFile(`${path.join(__dirname, '..', '..', 'public')}/index.html`);

  res.sendFile(`${pagePath}/homePage/homepage.html`);

});


module.exports = router;
