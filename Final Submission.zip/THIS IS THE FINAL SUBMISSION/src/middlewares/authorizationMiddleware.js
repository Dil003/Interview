
function authorize(roles) {

  return (req, res, next) => {
    if (roles.length === 0) {
      return res.status(500).send("There are no roles for this endpoint!");
    }

    const sessionRoles = req.session.roles;

    if (sessionRoles === undefined) {
      return res.status(401).send("No session roles found!");
    }

    if (roles.some(role => sessionRoles.includes(role))) {
      next();
    } else {
      return res.status(401).send("Invalid roles!");
    }
  };
}

module.exports = authorize;