const { initializeApp } = require('firebase-admin/app');

function setupFirebase(app) {
  initializeApp({
    projectId: 'wdcproject-78d0a',
  });
}

module.exports = setupFirebase;