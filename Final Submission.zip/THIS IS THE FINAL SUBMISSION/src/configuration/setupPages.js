
function setupPages(app) {

}

module.exports = setupPages;