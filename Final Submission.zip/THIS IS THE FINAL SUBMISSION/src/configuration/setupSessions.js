const session = require('express-session');

function setupSessions(app) {
  app.use(session({
    secret: 'some random string',
    resave: false,
    saveUninitialized: true,
    cookie: {secure: false}
  }));
}

module.exports = setupSessions;