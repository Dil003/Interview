const mysql = require('mysql2');

var dbConnectionPool = mysql.createPool({
  host: 'localhost',
  database: 'WDCProject'
}).promise();

function setupDatabase(app) {
  app.use(function(req, res, next) {
    req.pool = dbConnectionPool;
    next();
  });
}

module.exports = setupDatabase;